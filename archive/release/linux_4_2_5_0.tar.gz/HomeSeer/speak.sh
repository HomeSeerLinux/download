#!/bin/sh
flite -voice kal16 -t "$1"

