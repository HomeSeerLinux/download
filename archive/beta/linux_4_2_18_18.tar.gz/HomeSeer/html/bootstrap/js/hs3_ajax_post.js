<script type="text/javascript">
function commonAjaxPost(postData, page) {
    if (page.toLowerCase() == 'events') {
        page = 'event.html';
    }
 $.ajax({
  type: "POST",
  async: true,
  url: '/'+page,
  data: postData+'&hs3post=true',
  error: function() {
      $('div#errormessage').html('Page is refreshing...');
      $('div#contentdiv').html('');
  },
  beforeSend: function() {
  },
  success: function(response) { handleResponse(response,postData,true);}
 });
}
function handleResponse(response,postData,decode) {
   $('div#errormessage').html('');
   var sResponse;
   var id;
   try {
    if(decode)
     sResponse = eval('(' + response + ')');
    else
     sResponse=response;
   } catch(err) {sResponse='';}
   var nvPairs = postData.split('&');
   for (i = 0; i < nvPairs.length; i++)
   {
   var nvPair = nvPairs[i].split('=');
   var name = nvPair[0];
   var value = nvPair[1];
   if(name=='id') id=value;
   }
   for(i=0; i<sResponse.length; i+=2)
    {
     if(sResponse[i]==null) continue;
     if(sResponse[i].substr(0,5) == 'PAGE_') {
      var pageCmd=sResponse[i].substr(5);
      switch(pageCmd.toLowerCase()) {
       case 'executefunction':
           eval(sResponse[i+1]);
           break;
       case 'stoptimer':
           stopTimer();
           break;
       case 'starttimer':
           startTimer();
           break;
       case 'starttimerrunonce':
           startTimerRunOnce();
           break;
       case 'slidingtabopen':
           var strFun = sResponse[i+1] + '_open';
           var fn = window[strFun];
           fn();
           break;
       case 'slidingtabclose':
           var strFun = sResponse[i+1] + '_close';
           var fn = window[strFun];
           fn();
           break;
       case 'popmessage':
           alert(sResponse[i+1]);
           break;
       case 'stopspinner':
          $('#'+sResponse[i+1]).data('spinner').stop();
          break;
       case 'delayhide':
         delayid = sResponse[i+1];
         $('#'+delayid).oneTime(timerdelay, function() {
          $('#'+delayid).dialog('close');
         });
         break;
       case 'canceltimer':
         $('#'+sResponse[i+1]).stopTime();
         break;
       case 'timerdelay':
         timerdelay=parseInt(sResponse[i+1]);
         break;
       case 'closedialog':
         $('#'+sResponse[i+1]).dialog('close');
         break;
       case 'opendialog':
         try {
          var offset = $('#'+id).offset();
          $('#'+sResponse[i+1]).dialog( 'option', 'position', [offset.left+20,offset.top] );
         } catch(err) {}
         $('#'+sResponse[i+1]).dialog('open');
         break;
       case 'newpage':
         location.assign(sResponse[i+1]);
         break;
       case 'refresh':
        if(sResponse[i+1].toLowerCase() == 'true') {
         returnTrue = true;
         location.reload();
        }
        break;
      }
     }
     else if(sResponse[i].substr(0,5) == 'PROP_') {
      var allParts = sResponse[i+1];
      var allArray = allParts.split('=');
      var property = allArray[0];
      var value = allArray[1];
      var valueint = parseInt(allArray[1]);
      var elementID=sResponse[i].substr(5);
      switch(property.toLowerCase()) {
       case 'button':
        if(allArray[2]=='false') allArray[2]=false;
        if(allArray[2]=='true') allArray[2]=true;
        $('#' + elementID).button('option',value,allArray[2]);
        break;
       case 'prependdiv':
        $('#' + elementID).prepend(allParts.substr(11));
        break;
       case 'appenddiv':
        $('#' + elementID).append(allParts.substr(10));
        var height = $('#' + elementID).get(0).scrollHeight;
        $('#' + elementID).animate({
         scrollTop: height
        }, 500);
        break;
       case 'setcss':
        $('#' + elementID).css(value,allArray[2]);
        break;
       case 'addattr':
        $('#' + elementID).attr(value,allArray[2]);
        break;
       case 'removeattr':
        $('#' + elementID).removeAttr(value);
        break;
       case 'propid':
        if(allArray[2]=='false') allArray[2]=false;
        if(allArray[2]=='true') allArray[2]=true;
        $('#' + elementID).prop(value, allArray[2]);
        break;
       case 'propclass':
        if(allArray[2]=='false') allArray[2]=false;
        if(allArray[2]=='true') allArray[2]=true;
        $('.' + elementID).prop(value, allArray[2]);
        break;
       case 'progressbar':
        $('#' + elementID).progressbar('option', 'value', valueint);
        break;
       case 'expand':
        var optionValue = allArray[1];
        if(optionValue=='0') {
         $('#' + elementID + '_content').hide();
         var divs = $('#' + elementID).find('div');
         $('#' + elementID + '_span').removeClass('ui-icon-circle-minus').addClass('ui-icon-circle-plus');
         $('#' + elementID + '_sel').hide();
         $('#' + elementID + '_unsel').show();
        }
        else {
         $('#' + elementID + '_content').show();
         var divs = $('#' + elementID).find('div');
         $('#' + elementID + '_span').removeClass('ui-icon-circle-plus').addClass('ui-icon-circle-minus');
         $('#' + elementID + '_sel').show();
         $('#' + elementID + '_unsel').hide();
        }
        break;
       case 'option':
        var optionValue = allArray[2];
        if(optionValue.toLowerCase()=='false') optionValue=false;
        $('#' + elementID).accordion('option', 'animated', optionValue);
        break;
       case 'activate':
        if(value.toLowerCase()!='false') value = parseInt(value);
        $('#' + elementID).accordion('activate', value);
        break;
      }
     }
     else {
       var str = sResponse[i+1]
       $('.selector555').each(function(){
       var tmpID = this.id;
       if (str.indexOf(tmpID) >= 0)
       {
      $('#' + tmpID).dialog('destroy');
      $('#' + tmpID).remove();
       }
       });
      $('#' + sResponse[i]).empty();
      $('#' + sResponse[i]).html(sResponse[i+1]);
      after_postback(true);
     }
    }
   }
   function positionDialog(elementid,dialogid) {
     linkOffset = $('#'+elementid).offset();
     linkWidth = $('#'+elementid).width();
     linkHeight = $('#'+elementid).height();
     scrolltop = $(window).scrollTop();
     $('#'+dialogid).dialog('option', 'position', [linkOffset.left + linkWidth/2, linkOffset.top + linkHeight]);
    }
</script>