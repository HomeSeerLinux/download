function hideAllSubMenus() {
    $("li.nav-item.dropdown > div.dropdown-menu.homeseer").removeClass("d-block").hide();
    $("div.dropdown-menu.homeseer a.dropdown-toggle").removeClass("active");
}

$(document).ready(function () {
    $(".dropdown-toggle").dropdown();
    // SideNav Scrollbar Initialization
    var sideNavScrollbar = document.querySelector('.custom-scrollbar');
    var ps = new PerfectScrollbar(sideNavScrollbar);
    // SideNav Button Initialization
    $(".button-collapse").sideNav();
});

$("li.dropdown div.dropdown").on("hide.bs.dropdown", function(e) {
    $("li.dropdown > div.dropdown-menu.homeseer").removeClass("d-block").hide();
    $(this).find("div.dropdown-menu.homeseer a.dropdown-toggle").removeClass("active");
});

$("div.dropdown-menu.homeseer a.dropdown-toggle.homeseer").on("click", function(e) {
    var dropdownTarget = $("div.dropdown-menu[aria-labelledby='" + e.target.id + "']");
    if (dropdownTarget.hasClass("d-block") || $(this).hasClass("active")) {
        dropdownTarget.removeClass("d-block").hide();
        $(this).removeClass("active");
        e.stopPropagation();
        return;
    }
    hideAllSubMenus();
    var menuItemPos = $(this).position();
    // see HS-238 about this code
    var tarHeight = dropdownTarget.outerHeight();
    var newTop = menuItemPos.top + $("ul.nav.navbar-nav").outerHeight() - 8;
    if ((tarHeight + newTop) > $(window).height()) {
        newTop = $(window).height() - tarHeight -8;
    }
    dropdownTarget.css({
        top: newTop,
        //top: menuItemPos.top + $("ul.nav.navbar-nav").outerHeight() - 8,
        left: menuItemPos.left + Math.round($(this).outerWidth() * 0.95)
    });
    dropdownTarget.addClass("d-block").show();
    e.stopPropagation();
});

$("div.dropdown-menu.homeseer.plugins-menu").on("scroll", function(e) {
    hideAllSubMenus();
});