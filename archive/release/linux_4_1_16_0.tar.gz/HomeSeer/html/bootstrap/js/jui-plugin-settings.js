<script type="text/javascript" src="/bootstrap/js/jquery-3.4.0.min.js"></script>
<script type="text/javascript" src="/bootstrap/js/popper.min.js"></script>         
<script type="text/javascript" src="/bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="/bootstrap/js/mdb.min.js"></script>
<script type="text/javascript" src="/bootstrap/js/bootstrap-tagsinput.js"></script>
<script type="text/javascript">

    $(document).ready(function() {
        $('.datepicker').pickadate();
        $('.mdb-select').materialSelect();
    });
    $(document).on('click', 'button.jui-button-save', saveButtonClicked);
    $(document).on('click', 'button.cancel', cancelButtonClicked);
    $(document).on('change', '.jui-input', viewValueChanged);

    var changes = new Map();

    function initsliders() {
        // todo, fix so this is not needed
    }

    function saveButtonClicked(event) {
        blurActiveElement();
        var data = '';
        var changeList = [];
        var clickedButton = event.target;
        var clickedButtonId = clickedButton.id;
        var pluginId = clickedButton.attributes.getNamedItem("plugin").value;

        for (let ch of changes.values()) {
            changeList.push(ch);
        }

        var postData = {plugid: pluginId, buttonId: clickedButtonId, changes: changeList};
        data = JSON.stringify(postData);
        console.log(data);
        $.ajax({
            type: "POST",
            async: "true",
            url: '/plugwrapper.html',
            cache: false,
            data: data,
            success: function(response){
                if (response === "") {
                    window.location.reload();
                    return;
                }

                //TODO expand on this to make the response more robust
                alert("Unable to save changes : " + response);
            },
            error: function(){
                alert("Unable to save changes : Unknown Error");
            }
        });
    }

    function cancelButtonClicked(event) {
        window.location.reload();
    }

    function blurActiveElement() {
        document.activeElement.blur();
    }

    function OnViewChanged(pageid,id,type,value) {
        var viewChange = {PageId: pageid, Id: id, Type: type, Value: value};
        changes.set(id, viewChange);
        return;
    }

    function viewValueChanged(event) {
        var view = event.target;
        var pagediv = null;
        if (view.hasAttribute("par-id")) {
            pagediv = document.getElementById(view.getAttribute("par-id")).parentNode;
        }
        else {
            pagediv = document.getElementById(view.id + "-par").parentNode;
        }
		if (pagediv.classList.contains("jui-group")) {
            pagediv = pagediv.parentNode;
        }
        var pageid = pagediv.attributes.getNamedItem("pageid").value;
        if (view.type == 'checkbox') {
            OnViewChanged(pageid, view.id, 5, view.checked);
            return;
        }
        else if (view.type == 'radio') {
            OnViewChanged(pageid, view.name, 3, view.value);
            return;
        }
        else if (view.type == 'select-one') {
            event.stopPropagation();
            if (view.value == view.getAttribute("jui-orig-val")) {
                return;
            }
            OnViewChanged(pageid, view.id, 3, view.value);
            return;
        }

        OnViewChanged(pageid, view.id, 4, view.value);
    }
    
</script>