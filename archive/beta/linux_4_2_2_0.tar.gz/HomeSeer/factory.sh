#!/bin/bash
echo "This script will delete all user data, proceed? (YES/NO)"
read answer_input

if [ "$answer_input" != "YES" ]; then
 exit 0
fi
echo "Deleting user data..."
sudo rm wave_files/*
sudo rm Media/*
sudo rm Grammar/*
sudo rm Config/settings.ini.bak
sudo rm Logs/*
sudo rm Data/Backup/*
sudo rm -rf Data/Z-Wave
sudo rm Config/Z-Wave.ini
sudo rm Data/*.hsd
sudo rm -rf Data/*.json
sudo rm Data/Energy/Energy.hsd
sudo rm -rf Data/Z-Wave/*
sudo rm Wave/*
sudo rm ConfigBackup/*
sudo rmdir RestoreConfig
sudo rm html/*.zip
sudo rm -rf Updates3/*
sudo rm -rf Updates4/*
sudo rm Config/*.ini
sudo rm Config/users.cfg
sudo rm Config/*.bak
sudo rm Config/users.cfg.temp
sudo rm ~/.bash_history
sudo rm Config/licenses.bin
sudo rm getfiles.sh
sudo rm html/*.json
sudo rm html/custom.css
sudo rm updater.txt
sudo rm updater_override.json
sudo rm html/custom.css
sudo rm html/backups/*
sudo rm html/uploads/*
sudo rm last_exception.txt
