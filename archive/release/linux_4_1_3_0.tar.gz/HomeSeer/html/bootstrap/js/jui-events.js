

<script type="text/javascript">
    
    $(document).on('change', '.jui-input', viewValueChanged);

    var changes = new Map();
    
    function savejuiButtonClicked(event) {
        blurActiveElement();
        var clickedbutton = event.target;
        var containingformid = clickedbutton.attributes.getNamedItem("form").value;
        var containingform = document.getElementById(containingformid);
        var pagediv = containingform.getElementsByClassName("jui-page")[0];
        var pageid = pagediv.attributes.getNamedItem("pageid").value;
        var changelist = [];
        var data;
        for (let ch of changes.values()) {
            if (ch.PageId !== pageid) {
                continue;
            }
            changelist.push(ch);
        }
        var encodedviewchanges = btoa(JSON.stringify(changelist));
        var trigindex = containingform.attributes.getNamedItem("trigindex");
        if (trigindex != null) {
            var groupindex = containingform.attributes.getNamedItem("groupindex").value;
            data = "action=save_jui_trig" + "&index=" + trigindex.value + "&tgindex=" + groupindex + "&viewchanges=" + encodedviewchanges;
            SendPostback(data);
            return;
        }

        var actindex = containingform.attributes.getNamedItem("actindex");
        if (actindex != null) {
            data = "action=save_jui_act" + "&index=" + actindex.value + "&viewchanges=" + encodedviewchanges;
            SendPostback(data);
            return;
        }
    }
    
    function blurActiveElement() {
        document.activeElement.blur();
    }
    
    function SendPostback(data) {
        console.log(data);
        $.ajax({
            type: "POST",
            async: "true",
            url: 'event.html',
            cache: false,
            data: data,
            success: function(response){
                if (response === "") {
                    window.location.reload();
                    return;
                }

                //TODO expand on this to make the response more robust
                alert("Unable to save changes : " + response);
            },
            error: function(){
                alert("Unable to save changes : Unknown Error");
            }
        });
    }
    
    function viewValueChanged(event) {
        var view = event.target;
        var pagediv = null;
        if (view.hasAttribute("par-id")) {
            pagediv = document.getElementById(view.getAttribute("par-id")).parentNode;
        }
        else {
            pagediv = document.getElementById(view.id + ".par").parentNode;
        }
        var pageid = pagediv.attributes.getNamedItem("pageid").value;
        var viewchange;
        var viewid;
        var viewtype;
        var viewvalue;
        if (view.type == 'checkbox') {
            viewchange = {PageId: pageid, Id: view.id, Type: 5, Value: view.checked};
        }
        else if (view.type == 'radio') {
            viewchange = {PageId: pageid, Id: view.name, Type: 3, Value: view.value};
        }
        else if (view.type == 'select-one') {
            event.stopPropagation();
            if (view.value == view.getAttribute("jui-orig-val")) {
                return;
            }
            viewchange = {PageId: pageid, Id: view.id, Type: 3, Value: view.value};
        }
        else {
            var viewChange = {PageId: pageid, Id: view.id, Type: 4, Value: view.value};
            changes.set(view.id, viewChange);
            return;
        }

        var jsonviewchange = JSON.stringify(viewchange);
        var encodedviewchange = btoa(jsonviewchange);
        var data;
        
        var containingform = pagediv.parentNode;
        var trigindex = containingform.attributes.getNamedItem("trigindex");
        if (trigindex != null) {
            var groupindex = containingform.attributes.getNamedItem("groupindex").value;
            data = "action=update_jui_trig" + "&index=" + trigindex.value + "&tgindex=" + groupindex + "&viewchange=" + encodedviewchange;
            SendPostback(data);
            return;
        }
        
        var actindex = containingform.attributes.getNamedItem("actindex");
        if (actindex != null) {
            data = "action=update_jui_act" + "&index=" + actindex.value + "&viewchange=" + encodedviewchange;
            SendPostback(data);
            return;
        }
    }
</script>