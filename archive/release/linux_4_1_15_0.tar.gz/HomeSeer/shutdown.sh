#!/bin/sh
sleep 5
shutdown now
