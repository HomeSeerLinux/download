

<script type="text/javascript">
    
    $(document).on('change', '.jui-input', viewValueChanged);

    var changes = new Map();
    
    function savejuiButtonClicked(event) {
        blurActiveElement();
        var clickedbutton = event.target;
        var containingformid = clickedbutton.attributes.getNamedItem("form").value;
        var containingform = document.getElementById(containingformid);
        var pagediv = containingform.getElementsByClassName("jui-page")[0];
        var pageid = pagediv.attributes.getNamedItem("pageid").value;
        var changelist = [];
        var data;
        for (let ch of changes.values()) {
            if (ch.PageId !== pageid) {
                continue;
            }
            changelist.push(ch);
        }
        var encodedviewchanges = encodeURIComponent(btoa(JSON.stringify(changelist)));
        var trigindex = containingform.attributes.getNamedItem("trigindex");
        if (trigindex != null) {
            var groupindex = containingform.attributes.getNamedItem("groupindex").value;
            data = "action=save_jui_trig" + "&index=" + trigindex.value + "&tgindex=" + groupindex + "&viewchanges=" + encodedviewchanges;
            SendPostback(data);
            return;
        }

        var actindex = containingform.attributes.getNamedItem("actindex");
        if (actindex != null) {
            data = "action=save_jui_act" + "&index=" + actindex.value + "&viewchanges=" + encodedviewchanges;
            SendPostback(data);
            return;
        }
    }
    
    function blurActiveElement() {
        document.activeElement.blur();
    }
    
    function SendPostback(data) {
        console.log(data);
        $.ajax({
            type: "POST",
            async: "true",
            url: 'event.html',
            cache: false,
            data: data,
            success: function(response){
                if (response === "") {
                    window.location.reload();
                    return;
                }

                //TODO expand on this to make the response more robust
                alert("Unable to save changes : " + response);
            },
            error: function(){
                alert("Unable to save changes : Unknown Error");
            }
        });
    }
    
    function viewValueChanged(event) {
        var view = event.target;
		var viewIdEscaped = view.id.replace(/\./g, '\\.');
        var pagediv = $('div.container.jui-page:has(#' + viewIdEscaped + ')')[0];
        var pageid = pagediv.getAttribute("pageid");
        var viewchange;
        var viewid;
        var viewtype;
        var viewvalue;
        if (view.type == 'checkbox') {
            viewchange = {PageId: pageid, Id: view.id, Type: 5, Value: view.checked};
        }
        else if (view.type == 'radio') {
            viewchange = {PageId: pageid, Id: view.name, Type: 3, Value: view.value};
        }
        else if (view.type == 'select-one') {
            event.stopPropagation();
            if (view.value == view.getAttribute("jui-orig-val")) {
                return;
            }
            viewchange = {PageId: pageid, Id: view.id, Type: 3, Value: view.value};
        }
		else if (view.type == 'textarea') {
            var viewChange = {PageId: pageid, Id: view.id, Type: 12, Value: view.value};
            changes.set(view.id, viewChange);
            return;
        }
		else if (view.classList.contains('jui-timespan')) {
			var parentdiv = $('div.jui-view:has(#' + viewIdEscaped + ')')[0];
			var id = parentdiv.getAttribute("id");
			var days = $('#' + id + '-days').val();
			var hours = $('#' + id + '-hours').val();
			var minutes = $('#' + id + '-minutes').val();
			var seconds = $('#' + id + '-seconds').val();
			
			if (!seconds)
				seconds = 0;
			if (!minutes)
				minutes = 0;
			if (!hours)
				hours = 0;
			if (!days)
				days = 0;
			
			if (days < 0) {
				alert("Please enter a positive number of days");
				return;
			}
			if (hours < 0 || hours > 23) {
				alert("Please enter a number of hours between 0 and 23");
				return;
			}
			if (minutes < 0 || minutes > 59) {
				alert("Please enter a number of minutes between 0 and 59");
				return;
			}
			if (seconds < 0 || seconds > 59) {
				alert("Please enter a number of seconds between 0 and 59");
				return;
			}
			var timespan = days + '.' + hours + ':' + minutes + ':' + seconds;
            var viewChange = {PageId: pageid, Id: id, Type: 13, Value: timespan};
            changes.set(id, viewChange);
			return;
		}
        else {
            var viewChange = {PageId: pageid, Id: view.id, Type: 4, Value: view.value};
            changes.set(view.id, viewChange);
            return;
        }

        var jsonviewchange = JSON.stringify(viewchange);
        var encodedviewchange = encodeURIComponent(btoa(jsonviewchange));
        var data;
        
        var containingform = pagediv.parentNode;
        var trigindex = containingform.attributes.getNamedItem("trigindex");
        if (trigindex != null) {
            var groupindex = containingform.attributes.getNamedItem("groupindex").value;
            data = "action=update_jui_trig" + "&index=" + trigindex.value + "&tgindex=" + groupindex + "&viewchange=" + encodedviewchange;
            SendPostback(data);
            return;
        }
        
        var actindex = containingform.attributes.getNamedItem("actindex");
        if (actindex != null) {
            data = "action=update_jui_act" + "&index=" + actindex.value + "&viewchange=" + encodedviewchange;
            SendPostback(data);
            return;
        }
    }
</script>