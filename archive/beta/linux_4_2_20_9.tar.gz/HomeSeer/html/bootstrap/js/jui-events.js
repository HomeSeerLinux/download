

<script type="text/javascript">

    $(document).ready(function() {
        var fmt = '{{ system_date_format_date_picker "shortdatepattern"}}';
        var tfmt = '{{ system_date_format "shorttimepattern"}}';
        var time12;
        if(tfmt.includes('tt')) {
            time12 = true;
        }
        else {
            time12 = false;     
        }
        var datePickers = $('.datepicker.jui-date');
        for (var i = 0; i < datePickers.length; i++) {
            var datePicker = datePickers[i];
            $(datePicker).pickadate({
                format: fmt,
                close: 'Done',
                onSet: function(context) {
                    var viewIdEscaped = datePicker.id.replace(/\./g, '\\.');
					var pagediv = $('div.container.jui-page').has('#' + viewIdEscaped)[0];
                    var pageid = pagediv.getAttribute("pageid");
                    var containingform = pagediv.parentNode;
                    var trigindex = containingform.attributes.getNamedItem("trigindex");
                    if (trigindex != null) {
                        var eventref = containingform.attributes.getNamedItem("ref").value;
                        var groupindex = containingform.attributes.getNamedItem("groupindex").value;
                        var grpcond = containingform.attributes.getNamedItem("grpcond").value;
                        var actcond = containingform.attributes.getNamedItem("actcond").value;
                        var viewchange = { PageId: pageid, Id: datePicker.id, Type: 4, Value: datePicker.value };
                        sendViewChange("update_jui_trig", viewchange, eventref, trigindex.value, groupindex, grpcond, actcond, "");
                        return;
                    }
                    var actindex = containingform.attributes.getNamedItem("actindex");
                    if (actindex != null) {
                        var eventref = containingform.attributes.getNamedItem("ref").value;
                        var groupindex = containingform.attributes.getNamedItem("groupindex").value;
                        var grpact = containingform.attributes.getNamedItem("grpact").value;
                        var viewchange = {PageId: pageid, Id: datePicker.id, Type: 4, Value: datePicker.value };
                        sendViewChange("update_jui_act", viewchange, eventref, actindex.value, groupindex, "", "", grpact);
                        return;
                    }
                }});
					
        }
        var timePickers = $('.timepicker.jui-time');
        for (var i = 0; i < timePickers.length; i++) {
            var timePicker = timePickers[i];
            $(timePicker).pickatime({
                twelvehour: time12,
                vibrate: false,
                afterDone: function() {
                    var viewIdEscaped = timePicker.id.replace(/\./g, '\\.');
					var pagediv = $('div.container.jui-page').has('#' + viewIdEscaped)[0];
                    var pageid = pagediv.getAttribute("pageid");
                    var containingform = pagediv.parentNode;
                    var trigindex = containingform.attributes.getNamedItem("trigindex");
                    if (trigindex != null) {
                        var eventref = containingform.attributes.getNamedItem("ref").value;
                        var groupindex = containingform.attributes.getNamedItem("groupindex").value;
                        var grpcond = containingform.attributes.getNamedItem("grpcond").value;
                        var actcond = containingform.attributes.getNamedItem("actcond").value;
                        var viewchange = { PageId: pageid, Id: timePicker.id, Type: 4, Value: timePicker.value };
                        sendViewChange("update_jui_trig", viewchange, eventref, trigindex.value, groupindex, grpcond, actcond, "");
                        return;
                    }
                    var actindex = containingform.attributes.getNamedItem("actindex");
                    if (actindex != null) {
                        var eventref = containingform.attributes.getNamedItem("ref").value;
                        var groupindex = containingform.attributes.getNamedItem("groupindex").value;
                        var grpact = containingform.attributes.getNamedItem("grpact").value;
                        var viewchange = {PageId: pageid, Id: timePicker.id, Type: 4, Value: timePicker.value };
                        sendViewChange("update_jui_act", viewchange, eventref, actindex.value, groupindex, "", "", grpact);
                        return;
                    }
                }});
        }
    });
    $(document).on('change', '.jui-input', viewValueChanged);
    $(document).on('click', '.jui-btn-nav', navigateButtonClicked);

    function sendViewChange(action, viewChange, ref, index, groupIndex, grpcond, actcond, grpact) {
        var jsonviewchange = JSON.stringify(viewChange);
        var encodedviewchange = encodeURIComponent(base64Encode(jsonviewchange));
        var data;
        if (index == null) {
            return;
        }
        data = "action=" + action + "&ref=" + ref + "&index=" + index + "&viewchange=" + encodedviewchange;
        if (groupIndex != "") {
            data += "&groupindex=" + groupIndex;
        }
        if (grpcond != "") {
            data += "&grpcond=" + grpcond;
        }
        if (actcond != "") {
            data += "&actcond=" + actcond;
        }
        if (grpact != "") {
            data += "&grpact=" + grpact;
        }
        SendPostback(data, false);
    }
    
    function savejuiButtonClicked(event) {
        blurActiveElement();
        var clickedbutton = event.target;
        var containingformid = clickedbutton.attributes.getNamedItem("form").value;
        var containingform = document.getElementById(containingformid);
        var pagediv = containingform.getElementsByClassName("jui-page")[0];
        var pageid = pagediv.attributes.getNamedItem("pageid").value;
        var data;
        var trigindex = containingform.attributes.getNamedItem("trigindex");
        if (trigindex != null) {
            var eventref = containingform.attributes.getNamedItem("ref").value;
            var groupindex = containingform.attributes.getNamedItem("groupindex").value;
            var grpcond = containingform.attributes.getNamedItem("grpcond").value;
            var actcond = containingform.attributes.getNamedItem("actcond").value;
            data = "action=save_jui_trig" + "&ref=" + eventref + "&index=" + trigindex.value + "&groupindex=" + groupindex + "&grpcond=" + grpcond + "&actcond=" + actcond;
            SendPostback(data, true);
            return;
        }

        var actindex = containingform.attributes.getNamedItem("actindex");
        if (actindex != null) {
            var eventref = containingform.attributes.getNamedItem("ref").value;
            var groupindex = containingform.attributes.getNamedItem("groupindex").value;
            var grpact = containingform.attributes.getNamedItem("grpact").value;
            data = "action=save_jui_act" + "&ref=" + eventref + "&index=" + actindex.value+ "&groupindex=" + groupindex + "&grpact=" + grpact;
            SendPostback(data, true);
            return;
        }
    }
    
    function blurActiveElement() {
        document.activeElement.blur();
    }
    
    function SendPostback(data) {
        console.log(data);
        //Call AjaxPost defined in event.html
        AjaxPost(data, "event.html");
    }
	
	//encode a UTF-16 string to a base64 encoded string
	function base64Encode(str)
	{
		//convert the string to an array of UTF-16 codes (2 bytes for each char)
		var bytes = [];
		for (var i = 0; i < str.length; ++i)
		{
			var charCode = str.charCodeAt(i);
			bytes.push(charCode & 0xFF);
			bytes.push((charCode & 0xFF00) >>> 8);
		}
		
		//convert the array to an ASCII string (each byte converted to one char)
		var len = bytes.length;
		var buffer = "";
		for (var i = 0; i < len; i++)
		{
			buffer += String.fromCharCode(bytes[i]);
		}
		
		//encode the string to base64
		return window.btoa(buffer);
	}
    
    function viewValueChanged(event) {
        var view = event.target;
		var viewIdEscaped = view.id.replace(/\./g, '\\.');
		var pagediv = $('div.container.jui-page').has('#' + viewIdEscaped)[0];
        var pageid = pagediv.getAttribute("pageid");
        var viewchange;
		
        if (view.type == 'checkbox') {
            viewchange = {PageId: pageid, Id: view.id, Type: 5, Value: view.checked};
        }
        else if (view.type == 'radio') {
            viewchange = {PageId: pageid, Id: view.name, Type: 3, Value: view.value};
        }
        else if (view.type == 'select-one') {
            event.stopPropagation();
            if (view.value == view.getAttribute("jui-orig-val")) {
                return;
            }
            viewchange = {PageId: pageid, Id: view.id, Type: 3, Value: view.value};
        }
		else if (view.type == 'textarea') {
            viewchange = {PageId: pageid, Id: view.id, Type: 12, Value: view.value};
        }
		else if (view.classList.contains('jui-timespan')) {
			var parentlist = $('div.jui-view').has('#' + viewIdEscaped);
			var parentdiv = parentlist[parentlist.length - 1];
			var id = parentdiv.getAttribute("id");
			var days = $('#' + id + '-days').val();
			var hours = $('#' + id + '-hours').val();
			var minutes = $('#' + id + '-minutes').val();
			var seconds = $('#' + id + '-seconds').val();
			
			if (!seconds)
				seconds = 0;
			if (!minutes)
				minutes = 0;
			if (!hours)
				hours = 0;
			if (!days)
				days = 0;
			
			if (days < 0) {
				alert("Please enter a positive number of days");
				return;
			}
			if (hours < 0 || hours > 23) {
				alert("Please enter a number of hours between 0 and 23");
				return;
			}
			if (minutes < 0 || minutes > 59) {
				alert("Please enter a number of minutes between 0 and 59");
				return;
			}
			if (seconds < 0 || seconds > 59) {
				alert("Please enter a number of seconds between 0 and 59");
				return;
			}
			var timespan = days + '.' + hours + ':' + minutes + ':' + seconds;
            viewchange = {PageId: pageid, Id: id, Type: 13, Value: timespan};
		}
        else {
            viewchange = {PageId: pageid, Id: view.id, Type: 4, Value: view.value};
        }

        var jsonviewchange = JSON.stringify(viewchange);
        var encodedviewchange = encodeURIComponent(base64Encode(jsonviewchange));
        var data;
        
        var containingform = pagediv.parentNode;
        var trigindex = containingform.attributes.getNamedItem("trigindex");
        if (trigindex != null) {
            var eventref = containingform.attributes.getNamedItem("ref").value;
            var groupindex = containingform.attributes.getNamedItem("groupindex").value;
            var grpcond = containingform.attributes.getNamedItem("grpcond").value;
            var actcond = containingform.attributes.getNamedItem("actcond").value;
            data = "action=update_jui_trig" + "&ref=" + eventref + "&index=" + trigindex.value + "&groupindex=" + groupindex + "&grpcond=" + grpcond + "&actcond=" + actcond + "&viewchange=" + encodedviewchange;
            SendPostback(data);
            return;
        }
        
        var actindex = containingform.attributes.getNamedItem("actindex");
        if (actindex != null) {
            var eventref = containingform.attributes.getNamedItem("ref").value;
            var groupindex = containingform.attributes.getNamedItem("groupindex").value;
            var grpact = containingform.attributes.getNamedItem("grpact").value;
            data = "action=update_jui_act" + "&ref=" + eventref + "&index=" + actindex.value + "&groupindex=" + groupindex + "&grpact=" + grpact + "&viewchange=" + encodedviewchange;
            SendPostback(data);
            return;
        }
    }
    
    function navigateButtonClicked(event) {
        var button = event.target;
        var targetUrl = window.location.origin + button.dataset.url;
        window.location.assign(targetUrl);
    }
</script>