#!/bin/sh
/usr/local/bin/gpio -g write 2 1
/usr/local/bin/gpio -g write 3 1
/usr/local/bin/gpio -g write 4 1

if [ "$1" = "blue" ]; then
 /usr/local/bin/gpio -g write 4 0
fi
if [ "$1" = "green" ]; then
 /usr/local/bin/gpio -g write 3 0
fi
if [ "$1" = "red" ]; then
 /usr/local/bin/gpio -g write 2 0
fi
if [ "$1" = "yellow" ]; then
 /usr/local/bin/gpio -g write 3 0
 /usr/local/bin/gpio -g write 2 0
fi
exit

