#!/bin/sh
$1 
