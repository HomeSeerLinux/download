sudo wget http://homeseer.com/updates4/hs4_sel_$1.tar.gz
sudo tar xavf hs4_sel_$1.tar.gz
sudo chmod +x install.sh
sudo ./install.sh

