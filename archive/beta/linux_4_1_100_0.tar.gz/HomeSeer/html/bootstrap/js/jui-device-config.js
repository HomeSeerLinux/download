
<script type="text/javascript">

    $(document).ready(function() {
        $('.datepicker').pickadate();
        //$('.mdb-select').materialSelect();
    });
    $(document).on('click', 'button.jui-button-save', saveButtonClicked);
    $(document).on('change', '.jui-input', viewValueChanged);
    $(document).on('hide.bs.tab', 'a[data-toggle="tab"].jui', onHideJuiTab);
    
    var changes = new Map();
    var pluginPages = new Map();
    
    function onHideJuiTab(event) {
        var hidingTab = event.relatedTarget;
        var pageId = hidingTab.id;
        if (pluginPages.has(pageId)) {
            alert("There are configuration changes that still need to be saved on this tab.")
        }
    }
    
    function saveButtonClicked(event) {
        blurActiveElement();
        var numPages = pluginPages.size;
        if (numPages === 0) {
            return;
        }
        else if (numPages > 1 && !confirm("This will discard any unsaved changes made on other tabs.  Continue?")) {
            return;
        }

        var changeList = [];
        var clickedButton = event.target;
        var clickedButtonId = clickedButton.id;
        var pluginId = clickedButton.attributes.getNamedItem("plugin").value;
        var deviceRef = clickedButton.attributes.getNamedItem("devref").value;
        var selectedTab = $('div.tab-pane.active.show div.container.jui-page')[0];
        for (let ch of changes.values()) {
            if (ch.PageId !== selectedTab.getAttribute("pageid")) {
                continue;
            }
            changeList.push(ch);
        }

        var postData = {plugid: pluginId, devRef: deviceRef, buttonId: clickedButtonId, changes: changeList};
        sendChangeData(postData);
    }
    
    function sendChangeData(postData) {
        var data = '';
        data = JSON.stringify(postData);
        console.log(data);
        $.ajax({
            type: "POST",
            async: "true",
            url: '/plugwrapper.html',
            cache: false,
            data: data,
            success: function(response){
                if (response === "") {
                    window.location.reload();
                    return;
                }
    
                //TODO expand on this to make the response more robust
                alert("Unable to save changes : " + response);
            },
            error: function(){
                alert("Unable to save changes : Unknown Error");
            }
        });
    }
    
    function blurActiveElement() {
        document.activeElement.blur();
    }
    
    function OnViewChanged(pageid,id,type,value) {
        var viewChange = {PageId: pageid, Id: id, Type: type, Value: value};
        changes.set(id, viewChange);
        if (pluginPages.has(pageid)) {
            return;
        }

        var tabSaveButton = $('button.jui-button-save')[0];
        var pluginId = tabSaveButton.attributes.getNamedItem("plugin").value;
        pluginPages.set(pageid, pluginId);
    }
    
    function viewValueChanged(event) {
        var view = event.target;
		var viewIdEscaped = view.id.replace(/\./g, '\\.');
        var pagediv = $('div.container.jui-page:has(#' + viewIdEscaped + ')')[0];
        var pageid = pagediv.getAttribute("pageid");
        if (view.type == 'checkbox') {
            OnViewChanged(pageid, view.id, 5, view.checked);
            return;
        }
        else if (view.type == 'radio') {
            OnViewChanged(pageid, view.name, 3, view.value);
            return;
        }
        else if (view.type == 'select-one') {
            event.stopPropagation();
            if (view.value == view.getAttribute("jui-orig-val")) {
                return;
            }
            OnViewChanged(pageid, view.id, 3, view.value);
            return;
        }
		else if (view.type == 'textarea') {
            OnViewChanged(pageid, view.id, 12, view.value);
            return;
        }
		else if (view.classList.contains('jui-timespan')) {
			var parentdiv = $('div.jui-view:has(#' + viewIdEscaped + ')')[0];
			var id = parentdiv.getAttribute("id");
			var days = $('#' + id + '-days').val();
			var hours = $('#' + id + '-hours').val();
			var minutes = $('#' + id + '-minutes').val();
			var seconds = $('#' + id + '-seconds').val();
			
			if (!seconds)
				seconds = 0;
			if (!minutes)
				minutes = 0;
			if (!hours)
				hours = 0;
			if (!days)
				days = 0;
			
			if (days < 0) {
				alert("Please enter a positive number of days");
				return;
			}
			if (hours < 0 || hours > 23) {
				alert("Please enter a number of hours between 0 and 23");
				return;
			}
			if (minutes < 0 || minutes > 59) {
				alert("Please enter a number of minutes between 0 and 59");
				return;
			}
			if (seconds < 0 || seconds > 59) {
				alert("Please enter a number of seconds between 0 and 59");
				return;
			}
			var timespan = days + '.' + hours + ':' + minutes + ':' + seconds;
			
			OnViewChanged(pageid, id, 13, timespan);
            return;
		}
    
        OnViewChanged(pageid, view.id, 4, view.value);
    }
</script>