<script type="text/javascript" src="/bootstrap/js/jquery-3.4.0.min.js"></script>
<script type="text/javascript" src="/bootstrap/js/popper.min.js"></script>         
<script type="text/javascript" src="/bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="/bootstrap/js/mdb.min.js"></script>
<script type="text/javascript" src="/bootstrap/js/bootstrap-tagsinput.js"></script>

<script type="text/javascript">
function juiButtonClicked(event) {
	NotifyClientOfButtonClick(event.target.id);
}

function juiTabShown(event) {
	alert(event.target.id);
	Client.OnPageLoad(event.target.id);
}

function blurActiveElement() {
	document.activeElement.blur();
}
            
function juiViewValueChanged(event) {
	var view = event.target;
	var view = event.target;
	var pagediv = document.getElementById(view.id + "-par").parentNode;
	var pageid = pagediv.attributes.getNamedItem("pageid");
	if (view.type == 'checkbox') {
		Client.OnViewBoolChanged(pageid, view.id, 5, view.checked);
		return;
	}
	else if (view.type == 'radio') {
		Client.OnViewStringChanged(pageid, view.name, 3, view.value);
		return;
	}
	else if (view.type == 'select-one') {
		event.stopPropagation();
		Client.OnViewIntChanged(pageid, view.id, 3, view.value);
		return;
	}
	
	Client.OnViewStringChanged(pageid, view.id, 4, view.value);
}

function NotifyClientOfButtonClick(id) {
	Client.OnButtonClicked(id);
}

function clearFocus() {
	document.activeElement.blur();
}

$(document).ready(function() {
	$('.mdb-select').materialSelect();
});

$(document).on('click', '.jui-button', juiButtonClicked);
$(document).on('change', '.jui-input', juiViewValueChanged);
</script>