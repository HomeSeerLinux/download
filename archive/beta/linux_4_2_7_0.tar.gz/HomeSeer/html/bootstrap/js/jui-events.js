

<script type="text/javascript">
    
    $(document).on('change', '.jui-input', viewValueChanged);
    
    function savejuiButtonClicked(event) {
        blurActiveElement();
        var clickedbutton = event.target;
        var containingformid = clickedbutton.attributes.getNamedItem("form").value;
        var containingform = document.getElementById(containingformid);
        var pagediv = containingform.getElementsByClassName("jui-page")[0];
        var pageid = pagediv.attributes.getNamedItem("pageid").value;
        var data;
        var trigindex = containingform.attributes.getNamedItem("trigindex");
        if (trigindex != null) {
            var groupindex = containingform.attributes.getNamedItem("groupindex").value;
            data = "action=save_jui_trig" + "&index=" + trigindex.value + "&tgindex=" + groupindex;
            SendPostback(data, true);
            return;
        }

        var actindex = containingform.attributes.getNamedItem("actindex");
        if (actindex != null) {
            data = "action=save_jui_act" + "&index=" + actindex.value;
            SendPostback(data, true);
            return;
        }
    }
    
    function blurActiveElement() {
        document.activeElement.blur();
    }
    
    function SendPostback(data, refreshOnSuccess) {
        console.log(data);
        $.ajax({
            type: "POST",
            async: "true",
            url: 'event.html',
            cache: false,
            data: data,
            success: function(response){
                if (response === "") {
					if(refreshOnSuccess) {
						window.location.reload();
					}
                    return;
                }

                //TODO expand on this to make the response more robust
                alert("Unable to save changes : " + response);
            },
            error: function(){
                alert("Unable to save changes : Unknown Error");
            }
        });
    }
    
    function viewValueChanged(event) {
        var view = event.target;
		var viewIdEscaped = view.id.replace(/\./g, '\\.');
        var pagediv = $('div.container.jui-page:has(#' + viewIdEscaped + ')')[0];
        var pageid = pagediv.getAttribute("pageid");
        var viewchange;
		var refreshOnSuccess = false;
		
        if (view.type == 'checkbox') {
            viewchange = {PageId: pageid, Id: view.id, Type: 5, Value: view.checked};
			refreshOnSuccess = true;
        }
        else if (view.type == 'radio') {
            viewchange = {PageId: pageid, Id: view.name, Type: 3, Value: view.value};
			refreshOnSuccess = true;
        }
        else if (view.type == 'select-one') {
            event.stopPropagation();
            if (view.value == view.getAttribute("jui-orig-val")) {
                return;
            }
            viewchange = {PageId: pageid, Id: view.id, Type: 3, Value: view.value};
			refreshOnSuccess = true;
        }
		else if (view.type == 'textarea') {
            viewchange = {PageId: pageid, Id: view.id, Type: 12, Value: view.value};
        }
		else if (view.classList.contains('jui-timespan')) {
			var parentdiv = $('div.jui-view:has(#' + viewIdEscaped + ')')[0];
			var id = parentdiv.getAttribute("id");
			var days = $('#' + id + '-days').val();
			var hours = $('#' + id + '-hours').val();
			var minutes = $('#' + id + '-minutes').val();
			var seconds = $('#' + id + '-seconds').val();
			
			if (!seconds)
				seconds = 0;
			if (!minutes)
				minutes = 0;
			if (!hours)
				hours = 0;
			if (!days)
				days = 0;
			
			if (days < 0) {
				alert("Please enter a positive number of days");
				return;
			}
			if (hours < 0 || hours > 23) {
				alert("Please enter a number of hours between 0 and 23");
				return;
			}
			if (minutes < 0 || minutes > 59) {
				alert("Please enter a number of minutes between 0 and 59");
				return;
			}
			if (seconds < 0 || seconds > 59) {
				alert("Please enter a number of seconds between 0 and 59");
				return;
			}
			var timespan = days + '.' + hours + ':' + minutes + ':' + seconds;
            viewchange = {PageId: pageid, Id: id, Type: 13, Value: timespan};
		}
        else {
            viewchange = {PageId: pageid, Id: view.id, Type: 4, Value: view.value};
        }

        var jsonviewchange = JSON.stringify(viewchange);
        var encodedviewchange = encodeURIComponent(btoa(jsonviewchange));
        var data;
        
        var containingform = pagediv.parentNode;
        var trigindex = containingform.attributes.getNamedItem("trigindex");
        if (trigindex != null) {
            var groupindex = containingform.attributes.getNamedItem("groupindex").value;
            data = "action=update_jui_trig" + "&index=" + trigindex.value + "&tgindex=" + groupindex + "&viewchange=" + encodedviewchange;
            SendPostback(data, refreshOnSuccess);
            return;
        }
        
        var actindex = containingform.attributes.getNamedItem("actindex");
        if (actindex != null) {
            data = "action=update_jui_act" + "&index=" + actindex.value + "&viewchange=" + encodedviewchange;
            SendPostback(data, refreshOnSuccess);
            return;
        }
    }
</script>