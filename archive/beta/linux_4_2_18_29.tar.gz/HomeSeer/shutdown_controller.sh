#!/bin/bash

while pgrep -af mono.'*'\(HSConsole\)
do
    sleep 5
done
poweroff
