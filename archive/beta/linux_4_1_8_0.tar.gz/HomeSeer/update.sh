#!/bin/bash
# first make sure HS is shut down
# check if  process is running, mono should be the HomeSeer process
check_process() {
# echo "$ts:  checking $1"
 [ "$1" = "" ] && return 0
 [ `pgrep -n $1` ] && return 1 || return 0
}

# wait for the mono process to exit, HomeSeer will then be shut down
while [ 1 ]; do
 check_process "mono"
 if [ $? == 0 ]; then
  break
 fi
 sleep 2
done

# extract the update files and reboot
echo extracting $1
tar xvf $1
rm $1
echo "Update complete"
reboot

