<script type="text/javascript" src="/bootstrap/js/jquery-3.4.0.min.js"></script>
<script type="text/javascript" src="/bootstrap/js/popper.min.js"></script>         
<script type="text/javascript" src="/bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="/bootstrap/js/mdb.min.js"></script>
<script type="text/javascript" src="/bootstrap/js/bootstrap-tagsinput.js"></script>

<script type="text/javascript">
function juiButtonClicked(event) {
	NotifyClientOfButtonClick(event.target.id);
}

function juiTabShown(event) {
	alert(event.target.id);
	Client.OnPageLoad(event.target.id);
}

function blurActiveElement() {
	document.activeElement.blur();
}
            
function juiViewValueChanged(event) {
	var view = event.target;
	var view = event.target;
	var pagediv = document.getElementById(view.id + "-par").parentNode;
	var pageid = pagediv.attributes.getNamedItem("pageid");
	if (view.type == 'checkbox') {
		Client.OnViewBoolChanged(pageid, view.id, 5, view.checked);
		return;
	}
	else if (view.type == 'radio') {
		Client.OnViewStringChanged(pageid, view.name, 3, view.value);
		return;
	}
	else if (view.type == 'select-one') {
		event.stopPropagation();
		Client.OnViewIntChanged(pageid, view.id, 3, view.value);
		return;
	}
	else if (view.type == 'textarea') {
		Client.OnViewStringChanged(pageid, view.id, 12, view.value);
		return;
	}
	else if (view.classList.contains('jui-timespan')) {
        var parentdiv = $('div.jui-view').has('#' + viewIdEscaped)[0];
		var id = parentdiv.getAttribute("id");
		var days = $('#' + id + '-days').val();
		var hours = $('#' + id + '-hours').val();
		var minutes = $('#' + id + '-minutes').val();
		var seconds = $('#' + id + '-seconds').val();
		
		if (!seconds)
			seconds = 0;
		if (!minutes)
			minutes = 0;
		if (!hours)
			hours = 0;
		if (!days)
			days = 0;
		
		if (days < 0) {
			alert("Please enter a positive number of days");
			return;
		}
		if (hours < 0 || hours > 23) {
			alert("Please enter a number of hours between 0 and 23");
			return;
		}
		if (minutes < 0 || minutes > 59) {
			alert("Please enter a number of minutes between 0 and 59");
			return;
		}
		if (seconds < 0 || seconds > 59) {
			alert("Please enter a number of seconds between 0 and 59");
			return;
		}
		var timespan = days + '.' + hours + ':' + minutes + ':' + seconds;
		
		Client.OnViewStringChanged(pageid, id, 13, timespan);
		return;
	}
	
	Client.OnViewStringChanged(pageid, view.id, 4, view.value);
}

function NotifyClientOfButtonClick(id) {
	Client.OnButtonClicked(id);
}

function clearFocus() {
	document.activeElement.blur();
}

$(document).ready(function() {
	$('.mdb-select').materialSelect();
});

$(document).on('click', '.jui-button', juiButtonClicked);
$(document).on('change', '.jui-input', juiViewValueChanged);
</script>