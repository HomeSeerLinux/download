﻿/*
* jQuery UI NumberPicker 1.0.0
*
* Copyright 2010-2011, HomeSeer Technologies LLC

*
* Depends:
*	jquery.ui.core.js
*
*
*/

(function ($, undefined) {

    $.extend($.ui, { numberpicker: { version: "1.0.0"} });

    var PROP_NAME = 'numberpicker';
    var tpuuid = new Date().getTime();

    /* Time picker manager.
    Use the singleton instance of this class, $.timepicker, to interact with the time picker.
    Settings for (groups of) time pickers are maintained in an instance object,
    allowing multiple different settings on the same page. */

    function Numberpicker() {
        this.debug = false; // Change this to true to start debugging
        this._curInst = null; // The current instance in use
        this._isInline = false; // true if the instance is displayed inline
        this._disabledInputs = []; // List of time picker inputs that have been disabled
        this._numberpickerShowing = false; // True if the popup picker is showing , false if not
        this._inDialog = false; // True if showing within a "dialog", false if not
        this._dialogClass = 'ui-timepicker-dialog'; // The name of the dialog marker class
        this._mainDivId = 'ui-timepicker-div'; // The ID of the main timepicker division
        this._inlineClass = 'ui-timepicker-inline'; // The name of the inline marker class
        this._currentClass = 'ui-timepicker-current'; // The name of the current hour / minutes marker class
        this._dayOverClass = 'ui-timepicker-days-cell-over'; // The name of the day hover marker class


        this._defaults = { // Global defaults for all the time picker instances
            showOn: 'focus',    // 'focus' for popup on focus,
            // 'button' for trigger button, or 'both' for either (not yet implemented)
            button: null,                   // 'button' element that will trigger the timepicker
            showAnim: 'fadeIn',             // Name of jQuery animation for popup
            showOptions: {},                // Options for enhanced animations
            appendText: '',                 // Display text following the input box, e.g. showing the format
            onSelect: null,                 // Define a callback function when a hour / minutes is selected
            onClose: null,                  // Define a callback function when the timepicker is closed
            showLeadingZero: true,          // Define whether or not to show a leading zero for hours < 10. [true/false]
            zIndex: null,                   // specify zIndex
            numbers: {
                starts: 0,                  // first displayed hour
                ends: 23                    // last displayed hour
            },
            numberText: 'Number',           // Display text
            onNumberShow: null, 		    // callback for enabling / disabling on selectable hours  ex : function(hour) { return true; }
            rows: 4                         // number of rows for the input tables, minimum 2, makes more sense if you use multiple of 2 
        };

        this.tpDiv = $('<div id="' + this._mainDivId + '" class="ui-timepicker ui-widget ui-helper-clearfix ui-corner-all " style="display: none"></div>');
    }

    $.extend(Numberpicker.prototype, {
        /* Class name added to elements to indicate already configured with a time picker. */
        markerClassName: 'hasNumberpicker',

        /* Debug logging (if enabled). */
        log: function () {
            if (this.debug)
                console.log.apply('', arguments);
        },

        // TODO rename to "widget" when switching to widget factory
        _widgetNumberpicker: function () {
            return this.tpDiv;
        },

        /* Override the default settings for all instances of the time picker.
        @param  settings  object - the new settings to use as defaults (anonymous object)
        @return the manager object */
        setDefaults: function (settings) {
            extendRemove(this._defaults, settings || {});
            return this;
        },

        /* Attach the time picker to a jQuery selection.
        @param  target    element - the target input field or division or span
        @param  settings  object - the new settings to use for this time picker instance (anonymous) */
        _attachNumberpicker: function (target, settings) {
            // check for settings on the control itself - in namespace 'time:'
            var inlineSettings = null;

            var nodeName = target.nodeName.toLowerCase();
            var inline = (nodeName == 'div' || nodeName == 'span');

            if (!target.id) {
                this.uuid += 1;
                target.id = 'tp' + this.uuid;
            }
            var inst = this._newInst($(target), inline);
            inst.settings = $.extend({}, settings || {}, inlineSettings || {});
            if (nodeName == 'input') {
                this._connectNumberpicker(target, inst);
            } else if (inline) {
                this._inlineNumberpicker(target, inst);
            }
        },

        /* Create a new instance object. */
        _newInst: function (target, inline) {
            var id = target[0].id.replace(/([^A-Za-z0-9_-])/g, '\\\\$1'); // escape jQuery meta chars
            return { id: id, input: target, // associated target


                inline: inline, // is timepicker inline or not :
                tpDiv: (!inline ? this.tpDiv : // presentation div
                    $('<div class="' + this._inlineClass + ' ui-timepicker ui-widget  ui-helper-clearfix"></div>'))
            };
        },

        /* Attach the time picker to an input field. */
        _connectNumberpicker: function (target, inst) {
            var input = $(target);
            inst.append = $([]);
            inst.trigger = $([]);
            if (input.hasClass(this.markerClassName)) { return; }
            this._attachments(input, inst);
            input.addClass(this.markerClassName).
                keydown(this._doKeyDown).
                keyup(this._doKeyUp).
                bind("setData.numberpicker", function (event, key, value) {
                    inst.settings[key] = value;
                }).
                bind("getData.numberpicker", function (event, key) {
                    return this._get(inst, key);
                });
            //this._autoSize(inst);
            $.data(target, PROP_NAME, inst);
        },

        /* Handle keystrokes. */
        _doKeyDown: function (event) {
            var inst = $.numberpicker._getInst(event.target);
            var handled = true;
            inst._keyEvent = true;
            if ($.numberpicker._numberpickerShowing) {
                switch (event.keyCode) {
                    case 9: $.numberpicker._hideNumberpicker();
                        handled = false;
                        break; // hide on tab out
                    case 13:
                        $.numberpicker._updateSelectedValue(inst);
                        $.numberpicker._hideNumberpicker();

                        return false; // don't submit the form
                        break; // select the value on enter
                    case 27: $.numberpicker._hideNumberpicker();
                        break; // hide on escape
                    default: handled = false;
                }
            }
            else if (event.keyCode == 36 && event.ctrlKey) { // display the time picker on ctrl+home
                $.numberpicker._showNumberpicker(this);
            }
            else {
                handled = false;
            }
            if (handled) {
                event.preventDefault();
                event.stopPropagation();
            }
        },

        /* Update selected time on keyUp */
        /* Added verion 0.0.5 */
        _doKeyUp: function (event) {
            var inst = $.numberpicker._getInst(event.target);
            $.numberpicker._updateNumberpicker(inst);
        },

        /* Make attachments based on settings. */
        _attachments: function (input, inst) {
            var appendText = this._get(inst, 'appendText');
            var isRTL = this._get(inst, 'isRTL');
            if (inst.append) { inst.append.remove(); }
            if (appendText) {
                inst.append = $('<span class="' + this._appendClass + '">' + appendText + '</span>');
                input[isRTL ? 'before' : 'after'](inst.append);
            }
            input.unbind('focus.numberpicker', this._showNumberpicker);
            if (inst.trigger) { inst.trigger.remove(); }

            var showOn = this._get(inst, 'showOn');
            if (showOn == 'focus' || showOn == 'both') { // pop-up time picker when in the marked field
                input.bind("focus.numberpicker", this._showNumberpicker);
            }
            if (showOn == 'button' || showOn == 'both') { // pop-up time picker when 'button' element is clicked
                var button = this._get(inst, 'button');
                $(button).bind("click.numberpicker", function () {
                    if ($.numberpicker._numberpickerShowing && $.numberpicker._lastInput == input[0]) { $.numberpicker._hideNumberpicker(); }
                    else { $.numberpicker._showNumberpicker(input[0]); }
                    return false;
                });

            }
        },


        /* Attach an inline time picker to a div. */
        _inlineNumberpicker: function (target, inst) {
            var divSpan = $(target);
            if (divSpan.hasClass(this.markerClassName))
                return;
            divSpan.addClass(this.markerClassName).append(inst.tpDiv).
                bind("setData.numberpicker", function (event, key, value) {
                    inst.settings[key] = value;
                }).bind("getData.numberpicker", function (event, key) {
                    return this._get(inst, key);
                });
            $.data(target, PROP_NAME, inst);

            this._updateNumberpicker(inst);
            inst.tpDiv.show();
        },

        /* Pop-up the time picker for a given input field.
        @param  input  element - the input field attached to the time picker or
        event - if triggered by focus */
        _showNumberpicker: function (input) {
            input = input.target || input;
            if (input.nodeName.toLowerCase() != 'input') { input = $('input', input.parentNode)[0]; } // find from button/image trigger
            if ($.numberpicker._isDisabledNumberpicker(input) || $.numberpicker._lastInput == input) { return; } // already here

            // fix v 0.0.8 - close current timepicker before showing another one
            $.numberpicker._hideNumberpicker();

            var inst = $.numberpicker._getInst(input);
            if ($.numberpicker._curInst && $.numberpicker._curInst != inst) {
                $.numberpicker._curInst.tpDiv.stop(true, true);
            }
            var beforeShow = $.numberpicker._get(inst, 'beforeShow');
            extendRemove(inst.settings, (beforeShow ? beforeShow.apply(input, [input, inst]) : {}));
            inst.lastVal = null;
            $.numberpicker._lastInput = input;

            if ($.numberpicker._inDialog) { input.value = ''; } // hide cursor
            if (!$.numberpicker._pos) { // position below input
                $.numberpicker._pos = $.numberpicker._findPos(input);
                $.numberpicker._pos[1] += input.offsetHeight; // add the height
            }
            var isFixed = false;
            $(input).parents().each(function () {
                isFixed |= $(this).css('position') == 'fixed';
                return !isFixed;
            });
            if (isFixed && $.browser.opera) { // correction for Opera when fixed and scrolled
                $.numberpicker._pos[0] -= document.documentElement.scrollLeft;
                $.numberpicker._pos[1] -= document.documentElement.scrollTop;
            }
            var offset = { left: $.numberpicker._pos[0], top: $.numberpicker._pos[1] };
            $.numberpicker._pos = null;
            // determine sizing offscreen
            inst.tpDiv.css({ position: 'absolute', display: 'block', top: '-1000px' });
            $.numberpicker._updateNumberpicker(inst);


            // fix width for dynamic number of time pickers
            // and adjust position before showing
            offset = $.numberpicker._checkOffset(inst, offset, isFixed);
            inst.tpDiv.css({ position: ($.numberpicker._inDialog && $.blockUI ?
			'static' : (isFixed ? 'fixed' : 'absolute')), display: 'none',
                left: offset.left + 'px', top: offset.top + 'px'
            });
            if (!inst.inline) {
                var showAnim = $.numberpicker._get(inst, 'showAnim');
                var duration = $.numberpicker._get(inst, 'duration');
                var zIndex = $.numberpicker._get(inst, 'zIndex');
                var postProcess = function () {
                    $.numberpicker._numberpickerShowing = true;
                    var borders = $.numberpicker._getBorders(inst.tpDiv);
                    inst.tpDiv.find('iframe.ui-timepicker-cover'). // IE6- only
					css({ left: -borders[0], top: -borders[1],
					    width: inst.tpDiv.outerWidth(), height: inst.tpDiv.outerHeight()
					});
                };

                // if not zIndex specified in options, use target zIndex + 1
                if (!zIndex) {
                    zIndex = $(input).zIndex() + 1;
                }
                inst.tpDiv.zIndex(zIndex);

                if ($.effects && $.effects[showAnim]) {
                    inst.tpDiv.show(showAnim, $.numberpicker._get(inst, 'showOptions'), duration, postProcess);
                }
                else {
                    inst.tpDiv[showAnim || 'show']((showAnim ? duration : null), postProcess);
                }
                if (!showAnim || !duration) { postProcess(); }
                if (inst.input.is(':visible') && !inst.input.is(':disabled')) { inst.input.focus(); }
                $.numberpicker._curInst = inst;
            }
        },

        /* Generate the picker content. */
        _updateNumberpicker: function (inst) {
            var self = this;
            var borders = $.numberpicker._getBorders(inst.tpDiv);

            inst.tpDiv.empty().append(this._generateHTML(inst))
			.find('iframe.ui-timepicker-cover') // IE6- only
				.css({ left: -borders[0], top: -borders[1],
				    width: inst.tpDiv.outerWidth(), height: inst.tpDiv.outerHeight()
				})
			.end()
            // after the picker html is appended bind the click & double click events (faster in IE this way
            // then letting the browser interpret the inline events)
            // the binding for the minute cells also exists in _updateMinuteDisplay

            .find('.ui-timepicker-number-cell')
                .bind("click", { fromDoubleClick: false }, $.proxy($.numberpicker.selectNumber, this))
                .bind("dblclick", { fromDoubleClick: true }, $.proxy($.numberpicker.selectNumber, this))
            .end()
			.find('.ui-timepicker td a')
				.bind('mouseout', function () {
				    $(this).removeClass('ui-state-hover');
				    if (this.className.indexOf('ui-timepicker-prev') != -1) $(this).removeClass('ui-timepicker-prev-hover');
				    if (this.className.indexOf('ui-timepicker-next') != -1) $(this).removeClass('ui-timepicker-next-hover');
				})
				.bind('mouseover', function () {
				    if (!self._isDisabledNumberpicker(inst.inline ? inst.tpDiv.parent()[0] : inst.input[0])) {
				        $(this).parents('.ui-timepicker-calendar').find('a').removeClass('ui-state-hover');
				        $(this).addClass('ui-state-hover');
				        if (this.className.indexOf('ui-timepicker-prev') != -1) $(this).addClass('ui-timepicker-prev-hover');
				        if (this.className.indexOf('ui-timepicker-next') != -1) $(this).addClass('ui-timepicker-next-hover');
				    }
				})
			.end()
			.find('.' + this._dayOverClass + ' a')
				.trigger('mouseover')
			.end();
        },

        /* Generate the HTML for the current state of the date picker. */
        _generateHTML: function (inst) {

            var h, m, row, html = '',
                showLeadingZero = (this._get(inst, 'showLeadingZero') == true),
                rows = this._get(inst, 'rows'),
                numbers = Array(),
                numbers_options = this._get(inst, 'numbers'),
                numbersPerRow = null,
                numberCounter = 0,
                numberLabel = this._get(inst, 'numberText');



            // prepare all hours and minutes, makes it easier to distribute by rows
            for (h = numbers_options.starts; h <= numbers_options.ends; h++) {
                numbers.push(h);
            }
            numbersPerRow = Math.round(numbers.length / rows + 0.49); // always round up



            html = '<table class="ui-timepicker-table ui-widget-content ui-corner-all"><tr>' +
                   '<td class="ui-timepicker-hours">' +
                   '<div class="ui-timepicker-title ui-widget-header ui-helper-clearfix ui-corner-all">' +
                   numberLabel +
                   '</div>' +
                   '<table class="ui-timepicker">';

            for (row = 1; row <= rows; row++) {
                html += '<tr>';

                while (numberCounter < numbersPerRow * row) {
                    html += this._generateHTMLNumberCell(inst, numbers[numberCounter], showLeadingZero);
                    numberCounter++;
                }
                html += '</tr>';
            }

            html += '</tr></table>'; // Close the hours cells table

            html += '</td></tr></table>';

            /* IE6 IFRAME FIX (taken from datepicker 1.5.3, fixed in 0.1.2 */
            html += ($.browser.msie && parseInt($.browser.version, 10) < 7 && !inst.inline ?
                '<iframe src="javascript:false;" class="ui-timepicker-cover" frameborder="0"></iframe>' : '');

            return html;
        },


        /* Generate the content of a "Hour" cell */
        _generateHTMLNumberCell: function (inst, number, showLeadingZero) {

            var displayNumber = number;

            if ((displayNumber < 10) && showLeadingZero) {
                displayNumber = '0' + displayNumber;
            }

            var html = "";
            var enabled = true;
            var onNumberShow = this._get(inst, 'onNumberShow'); 	//custom callback

            if (number == undefined) {
                html = '<td class="ui-state-default ui-state-disabled">&nbsp;</td>';
                return html;
            }

            if (onNumberShow) {
                enabled = onNumberShow.apply((inst.input ? inst.input[0] : null), [hour]);
            }

            if (enabled) {
                html = '<td class="ui-timepicker-number-cell" data-timepicker-instance-id="#' + inst.id.replace("\\\\", "\\") + '" data-number="' + number.toString() + '">' +
                   '<a class="ui-state-default ' +
                   (number == inst.number ? 'ui-state-active' : '') +
                   '">' +
                   displayNumber.toString() +
                   '</a></td>';
            }
            else {
                html =
            		'<td>' +
		                '<span class="ui-state-default ui-state-disabled ' +
		                (number == inst.number ? ' ui-state-active ' : ' ') +
		                '">' +
		                displayNumber.toString() +
		                '</span>' +
		            '</td>';
            }
            return html;
        },



        /* Is the first field in a jQuery collection disabled as a timepicker?
        @param  target    element - the target input field or division or span
        @return boolean - true if disabled, false if enabled */
        _isDisabledNumberpicker: function (target) {
            if (!target) { return false; }
            for (var i = 0; i < this._disabledInputs.length; i++) {
                if (this._disabledInputs[i] == target) { return true; }
            }
            return false;
        },

        /* Check positioning to remain on screen. */
        _checkOffset: function (inst, offset, isFixed) {
            var tpWidth = inst.tpDiv.outerWidth();
            //alert('tpwidth:' + tpWidth);
            var tpHeight = inst.tpDiv.outerHeight();
            var inputWidth = inst.input ? inst.input.outerWidth() : 0;
            //alert('inputw:' + inputWidth);
            var inputHeight = inst.input ? inst.input.outerHeight() : 0;
            var viewWidth = document.documentElement.clientWidth + $(document).scrollLeft();
            var viewHeight = document.documentElement.clientHeight + $(document).scrollTop();

            offset.left -= (this._get(inst, 'isRTL') ? (tpWidth - inputWidth) : 0);
            offset.left -= (isFixed && offset.left == inst.input.offset().left) ? $(document).scrollLeft() : 0;
            offset.top -= (isFixed && offset.top == (inst.input.offset().top + inputHeight)) ? $(document).scrollTop() : 0;

            // now check if datepicker is showing outside window viewport - move to a better place if so.
            offset.left -= Math.min(offset.left, (offset.left + tpWidth > viewWidth && viewWidth > tpWidth) ?
			Math.abs(offset.left + tpWidth - viewWidth) : 0);
            offset.top -= Math.min(offset.top, (offset.top + tpHeight > viewHeight && viewHeight > tpHeight) ?
			Math.abs(tpHeight + inputHeight) : 0);

            return offset;
        },

        /* Find an object's position on the screen. */
        _findPos: function (obj) {
            var inst = this._getInst(obj);
            var isRTL = this._get(inst, 'isRTL');
            while (obj && (obj.type == 'hidden' || obj.nodeType != 1)) {
                obj = obj[isRTL ? 'previousSibling' : 'nextSibling'];
            }
            var position = $(obj).offset();
            return [position.left, position.top];
        },

        /* Retrieve the size of left and top borders for an element.
        @param  elem  (jQuery object) the element of interest
        @return  (number[2]) the left and top borders */
        _getBorders: function (elem) {
            var convert = function (value) {
                return { thin: 1, medium: 2, thick: 3}[value] || value;
            };
            return [parseFloat(convert(elem.css('border-left-width'))),
			parseFloat(convert(elem.css('border-top-width')))];
        },


        /* Close time picker if clicked elsewhere. */
        _checkExternalClick: function (event) {
            if (!$.numberpicker._curInst) { return; }
            var $target = $(event.target);
            if ($target[0].id != $.numberpicker._mainDivId &&
				$target.parents('#' + $.numberpicker._mainDivId).length == 0 &&
				!$target.hasClass($.numberpicker.markerClassName) &&
				!$target.hasClass($.numberpicker._triggerClass) &&
				$.numberpicker._numberpickerShowing && !($.numberpicker._inDialog && $.blockUI))
                $.numberpicker._hideNumberpicker();
        },

        /* Hide the time picker from view.
        @param  input  element - the input field attached to the time picker */
        _hideNumberpicker: function (input) {
            var inst = this._curInst;
            if (!inst || (input && inst != $.data(input, PROP_NAME))) { return; }
            if (this._numberpickerShowing) {
                var showAnim = this._get(inst, 'showAnim');
                var duration = this._get(inst, 'duration');
                var postProcess = function () {
                    $.numberpicker._tidyDialog(inst);
                    this._curInst = null;
                };
                if ($.effects && $.effects[showAnim]) {
                    inst.tpDiv.hide(showAnim, $.numberpicker._get(inst, 'showOptions'), duration, postProcess);
                }
                else {
                    inst.tpDiv[(showAnim == 'slideDown' ? 'slideUp' :
					    (showAnim == 'fadeIn' ? 'fadeOut' : 'hide'))]((showAnim ? duration : null), postProcess);
                }
                if (!showAnim) { postProcess(); }
                var onClose = this._get(inst, 'onClose');
                if (onClose) {
                    onClose.apply(
                        (inst.input ? inst.input[0] : null),
					    [(inst.input ? inst.input.val() : ''), inst]);  // trigger custom callback
                }
                this._numberpickerShowing = false;
                this._lastInput = null;
                if (this._inDialog) {
                    this._dialogInput.css({ position: 'absolute', left: '0', top: '-100px' });
                    if ($.blockUI) {
                        $.unblockUI();
                        $('body').append(this.tpDiv);
                    }
                }
                this._inDialog = false;
            }
        },

        /* Tidy up after a dialog display. */
        _tidyDialog: function (inst) {
            inst.tpDiv.removeClass(this._dialogClass).unbind('.ui-timepicker');
        },

        /* Retrieve the instance data for the target control.
        @param  target  element - the target input field or division or span
        @return  object - the associated instance data
        @throws  error if a jQuery problem getting data */
        _getInst: function (target) {
            try {
                return $.data(target, PROP_NAME);
            }
            catch (err) {
                throw 'Missing instance data for this timepicker';
            }
        },

        /* Get a setting value, defaulting if necessary. */
        _get: function (inst, name) {
            return inst.settings[name] !== undefined ?
			inst.settings[name] : this._defaults[name];
        },


        /* Set the dates for a jQuery selection.
        @param  target   element - the target input field or division or span
        @param  date     Date - the new date */
        _setTimeNumberpicker: function (target, time) {
            var inst = this._getInst(target);
            if (inst) {
                this._updateNumberpicker(inst);
            }
        },



        selectNumber: function (event) {
            var $td = $(event.currentTarget);
            var id = $td.attr("data-timepicker-instance-id");
            var newNumber = $td.attr("data-number");
            var fromDoubleClick = event.data.fromDoubleClick;

            var target = $(id);
            var inst = this._getInst(target[0]);
            $td.parents('.ui-timepicker-seconds:first').find('a').removeClass('ui-state-active');
            $td.children('a').addClass('ui-state-active');

            inst.number = newNumber;
            this._updateSelectedValue(inst);

            $.numberpicker._hideNumberpicker();
            // return false because if used inline, prevent the url to change to a hashtag
            return false;

        },

        _updateSelectedValue: function (inst) {
            var newNumber = inst.number;
            if (inst.input) {
                inst.input.val(newNumber);
                inst.input.trigger('change');
            }
            var onSelect = this._get(inst, 'onSelect');
            if (onSelect) { onSelect.apply((inst.input ? inst.input[0] : null), [newNumber, inst]); } // trigger custom callback
            return newNumber;
        },


        /* This might look unused but it's called by the $.fn.timepicker function with param getTime */
        /* added v 0.2.3 - gitHub issue #5 - Thanks edanuff */
        _getTimeNumberpicker: function (input) {
            var inst = this._getInst(input);
            return inst.number;
        },
        _getHourNumberpicker: function (input) {
            var inst = this._getInst(input);
            return inst.hours;
        },
        _getMinuteNumberpicker: function (input) {
            var inst = this._getInst(input);
            return inst.minutes;
        },
        _getSecondNumberpicker: function (input) {
            var inst = this._getInst(input);
            return inst.seconds;
        }

    });



    /* Invoke the timepicker functionality.
    @param  options  string - a command, optionally followed by additional parameters or
    Object - settings for attaching new timepicker functionality
    @return  jQuery object */
    $.fn.numberpicker = function (options) {

        /* Initialise the number picker. */
        if (!$.numberpicker.initialized) {
            $(document).mousedown($.numberpicker._checkExternalClick).
			find('body').append($.numberpicker.tpDiv);
            $.numberpicker.initialized = true;
        }

        var otherArgs = Array.prototype.slice.call(arguments, 1);
        if (typeof options == 'string' && (options == 'getTime' || options == 'getHour' || options == 'getMinute'))
            return $.numberpicker['_' + options + 'Numberpicker'].
			apply($.numberpicker, [this[0]].concat(otherArgs));
        if (options == 'option' && arguments.length == 2 && typeof arguments[1] == 'string')
            return $.numberpicker['_' + options + 'Numberpicker'].
			apply($.numberpicker, [this[0]].concat(otherArgs));
        return this.each(function () {
            typeof options == 'string' ?
			$.numberpicker['_' + options + 'Numberpicker'].
				apply($.numberpicker, [this].concat(otherArgs)) :
			$.numberpicker._attachNumberpicker(this, options);
        });
    };

    /* jQuery extend now ignores nulls! */
    function extendRemove(target, props) {
        $.extend(target, props);
        for (var name in props)
            if (props[name] == null || props[name] == undefined)
                target[name] = props[name];
        return target;
    };

    $.numberpicker = new Numberpicker(); // singleton instance
    $.numberpicker.initialized = false;
    $.numberpicker.uuid = new Date().getTime();
    $.numberpicker.version = "1.0.0";

    // Workaround for #4055
    // Add another global to avoid noConflict issues with inline event handlers
    window['TP_jQuery_' + tpuuid] = $;

})(jQuery);