
<script type="text/javascript" src="/bootstrap/js/jquery-3.4.0.min.js"></script>
<script type="text/javascript" src="/bootstrap/js/popper.min.js"></script>         
<script type="text/javascript" src="/bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="/bootstrap/js/mdb.js"></script>
<script type="text/javascript" src="/bootstrap/js/js.cookie.min.js"></script>
<script type="text/javascript" src="/bootstrap/js/pickr.min.js"></script>
<script type="text/javascript" src="/bootstrap/js/sweetalert/sweetalert2.min.js"></script>

	
<script type="text/javascript">
var touchDevice = (navigator.maxTouchPoints || 'ontouchstart' in document.documentElement);
$(document).ready(function() {	
    $('.mdb-select').materialSelect();
    $('.side-nav-collapse').sideNav();
    $('[data-toggle="tooltip"]').tooltip({trigger : 'hover'});
	$('[data-tooltip="tooltip"]').tooltip({trigger : 'hover'});	// in case a tooltip is needed on an element with a modal
    
    
            // save the current session as a cookie for later page GETS
    Cookies.set('session', {{ current_session }});
    
    if(!touchDevice) {
    }   
    else {
        // on mobile the tooltip does not close when a dialog opens, this forces them to close
        $('.modal').on('show.bs.modal', function (e) {
            $('[data-toggle="tooltip"]').tooltip('hide');
            $('[data-tooltip="tooltip"]').tooltip('hide');
        });
    }

    $(document).on('click', '#nav-search-button', {}, function (e) {
        var data;
        $(this.attributes).each(function() {				
			var parts = this.nodeName+"="+this.nodeValue;            
			if(data==null) {
				data = parts;
			}
			else {
				data = data+"&"+parts;
			}
		});
        var fdata = $('#searchform-top').serialize(); 
        data=data+'&'+fdata;
        AjaxPost(data,"search.html");
    });

});

function ConfirmAction(action,action_text,id_name,id,page) {
    Swal.fire({
            title: 'Warning!',
            text: 'Are you sure? ' + action_text,
            buttonStyling: false,
            showClass: {
            popup: 'swal2-noanimation',
            backdrop: 'swal2-noanimation'
            },
            hideClass: {
            popup: '',
            backdrop: ''
            },
            position: 'top',
            focusConfirm: false,
            reverseButtons: true,
            showCancelButton: true,
            cancelButtonText: 'No',
            confirmButtonText: 'Yes'
        }).then((result) => {
            if (result.value) {
                AjaxPost('action=' + action + '&' + id_name + '=' + id,page); 
            }
        })                        
    }

function AjaxPost(data,page){
    $.ajax({
        type: "POST",
        async: "true",
        url: '/'+page,
        cache:false,
        data: data,
        success: function (response) {
        var do_after_postback = false;
            if (response == '') {
             	after_postback();
                return;
            }
            var sResponse;
            sResponse = eval('(' + response + ')');

            for(i=0; i<sResponse.length; i+=2) {
                if(sResponse[i]==null) continue;
                if(sResponse[i].substr(0,5) == 'PAGE_') {
                    var pageCmd=sResponse[i].substr(5);
                    switch(pageCmd.toLowerCase()) {
                        case 'popmessage':
                            alert(sResponse[i + 1]);
                            after_postback();
                            break;
                        case 'newpage':
                            location.assign(sResponse[i+1]);
							//window.location.replace(sResponse[i+1]);
                            break;
                        case 'refresh':
                            if(sResponse[i+1].toLowerCase() == 'true') {
                                returnTrue = true;
                                location.reload();
                            }
                            break; 
                        case 'data':
                            after_postback_data(sResponse[i+1]);
                    }
                }
                else {
                    $('#' + sResponse[i]).empty();
                    $('#' + sResponse[i]).html(sResponse[i+1]);
                    do_after_postback=true;                    
                }
            }   
            if(do_after_postback) {
                after_postback(true);
            }
        },
        error: function(){
            //alert("Error");
            after_postback(false);
        }
    });
}

function AjaxPostSync(data,page){
    $.ajax({
        type: "POST",
        async: "false",
        url: '/'+page,
        cache:false,
        data: data,
        success: function (response) {
            if (response == '') {
             	after_postback();
                return;
            }
            var sResponse;
            sResponse = eval('(' + response + ')');

            for(i=0; i<sResponse.length; i+=2) {
                if(sResponse[i]==null) continue;
                if(sResponse[i].substr(0,5) == 'PAGE_') {
                    var pageCmd=sResponse[i].substr(5);
                    switch(pageCmd.toLowerCase()) {
                        case 'popmessage':
                            alert(sResponse[i + 1]);
                            after_postback();
                            break;
                        case 'newpage':
                            location.assign(sResponse[i+1]);
							//window.location.replace(sResponse[i+1]);
                            break;
                        case 'refresh':
                            if(sResponse[i+1].toLowerCase() == 'true') {
                                returnTrue = true;
                                location.reload();
                            }
                            break; 
                        case 'data':
                            after_postback_data(sResponse[i+1]);
                    }
                }
                else {
                    $('#' + sResponse[i]).empty();
                    $('#' + sResponse[i]).html(sResponse[i+1]);
                    after_postback(true);
                }
            }            
        },
        error: function(){
            //alert("Error");
            after_postback(false);
        }
    });
}

{{includefile 'bootstrap/js/navbar.js'}}

</script>