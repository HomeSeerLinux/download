﻿public object Main(object[] Parms)
{

hs.WriteLog("CSHARP","From C# script");

String s = DateTime.Now.ToString("ddd");
hs.WriteLog("C#","Day: " + s);
Console.WriteLine("hello");
return 0;
}