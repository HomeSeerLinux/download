#!/bin/bash


counter=20
while [ $counter -gt 0 ]
do
 sleep 1
 counter=$(($counter - 1))
done

# now restart system
reboot

