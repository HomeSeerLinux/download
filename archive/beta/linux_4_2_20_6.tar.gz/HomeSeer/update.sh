#!/bin/bash
# first make sure HS is shut down
while pgrep -af mono.'*'\(HSConsole\)
do
    sleep 5
done

# extract the update files and reboot
echo extracting $1
tar xvf $1
rm $1
echo "Update complete"
reboot

