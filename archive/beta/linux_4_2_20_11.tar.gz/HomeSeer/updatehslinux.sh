sudo wget http://homeseer.com/updates4/linux_$1.tar.gz
sudo tar xavf linux_$1.tar.gz
sudo chmod +x install.sh
sudo ./install.sh

