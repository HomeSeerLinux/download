#!/bin/sh
echo  running command $1
$1 | aha
